import logo from './logo.svg';
import './App.css';
import Registrationform from './components/Registrationform';
function App() {
  return (
    <div className="App">
      <Registrationform/>
    </div>
  );
}

export default App;
