package com.registrationform.registrationform;

import org.springframework.data.repository.CrudRepository;

public interface RegRepo extends CrudRepository<RegEntity, Long>{

}
